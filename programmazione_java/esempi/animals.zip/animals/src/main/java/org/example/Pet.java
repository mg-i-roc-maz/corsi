package org.example;

public interface Pet {
    void play();
}
